
// Video
let video;
let classifier;
let modelURL = 'https://teachablemachine.withgoogle.com/models/yqkGr6FmZ/';
let label= "waiting...";
let button;
var words = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];


  
// STEP 1: Load the model!
function preload() {
  classifier = ml5.imageClassifier(modelURL+ 'model.json');
}

function setup() {
  createCanvas(640, 520);
  //Create the Button
var drawButton= createButton("Give me a letter!");
  drawButton.mousePressed(giveLetter);
  drawButton.position(290,165);
  drawButton.size(150,50)
  // Create the video
  video = createCapture(VIDEO);
  video.hide();
  
 //STEP 2: Start classifying
  classifyVideo();
}

// STEP 2 classify!
function classifyVideo() {
  classifier.classify(video, gotResults);

}
function giveLetter(){
  var rand = round(random(words.length -1));
 var whatToSign= words[rand];
 createP(whatToSign);
 
}
function draw() {
  background(0);
  
  // Draw the video
  image(video, 0, 0);
  
  //STEP 4: Draw the label
textSize(32);
textAlign(CENTER,CENTER);
fill(255);
text(label,width/2, height - 16);

}


// STEP 3: Get the classification!
function gotResults(error, results) {
  // Something went wrong!
  if (error) {
    console.error(error);
    return;
  }
  // store the label and classify again
    label= results[0].label;
    classifyVideo();
}

 
